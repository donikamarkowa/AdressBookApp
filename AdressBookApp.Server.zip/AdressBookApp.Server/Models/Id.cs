﻿namespace AdressBookApp.Server.Models
{
    public class Id
    {
        public string Name { get; set; } = null!;
        public string Value { get; set; } = null!;
    }
}
