﻿namespace AdressBookApp.Server.Models
{
    public class Name
    {
        public string Title { get; set; } = null!;
        public string First { get; set; } = null!;
        public string Last { get; set; } = null!;
    }
}
