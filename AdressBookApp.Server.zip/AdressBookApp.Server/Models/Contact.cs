﻿namespace AdressBookApp.Server.Models
{
    public class Contact
    {
        public Result[] Results { get; set; } = null!;
        public Info Info { get; set; } = null!;
    }
}
