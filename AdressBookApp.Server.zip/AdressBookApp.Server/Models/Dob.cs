﻿namespace AdressBookApp.Server.Models
{
    public class Dob
    {
        public DateTime Date { get; set; }
        public int Age { get; set; }
    }
}
