﻿namespace AdressBookApp.Server.Models
{
    public class Picture
    {
        public string Large { get; set; } = null!;
        public string Medium { get; set; } = null!;
        public string Thumbnail { get; set; } = null!;
    }
}
