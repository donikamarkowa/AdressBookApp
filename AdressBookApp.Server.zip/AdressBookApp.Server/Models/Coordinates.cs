﻿namespace AdressBookApp.Server.Models
{
    public class Coordinates
    {
        public string Latitude { get; set; } = null!;
        public string Longitude { get; set; } = null!;
    }
}
