﻿namespace AdressBookApp.Server.Models
{
    public class Timezone
    {
        public string Offset { get; set; } = null!;
        public string Description { get; set; } = null!;
    }
}
