﻿namespace AdressBookApp.Server.Models
{
    public class Registered
    {
        public DateTime Date { get; set; }
        public int Age { get; set; }
    }
}
