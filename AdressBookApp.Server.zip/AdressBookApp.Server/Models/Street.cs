﻿namespace AdressBookApp.Server.Models
{
    public class Street
    {
        public int Number { get; set; }
        public string Name { get; set; } = null!;
    }
}
